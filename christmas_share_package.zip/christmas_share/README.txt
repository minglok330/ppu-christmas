噗噗的圣诞树 - 分享部署说明

网页入口：index.html

将 index.html 上传到静态网页托管服务即可获得可分享的公开网址。
建议使用 GitHub Pages：
1. 登录/注册 GitHub。
2. 新建一个公开 repository（例如 ppu-christmas）。
3. 上传 index.html 到 repository 根目录。
4. Settings -> Pages -> Build and deployment，选择 Deploy from a branch。
5. 选择 main branch / root，保存。
6. 等待部署后，GitHub 会显示公开网址，可复制给微信好友。

手机访问时，建议用微信内置浏览器或手机浏览器打开网址。
